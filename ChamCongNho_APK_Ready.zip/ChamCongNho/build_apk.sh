#!/usr/bin/env bash
set -e
echo "=== Đang biên dịch Nhắc Chấm Công APK (assembleDebug) ==="
if command -v gradle >/dev/null 2>&1; then
  gradle assembleDebug --no-daemon
  echo "Hoàn tất! File APK nằm tại: app/build/outputs/apk/debug/app-debug.apk"
else
  echo "Không tìm thấy lệnh gradle. Hãy tải dự án lên GitHub để GitHub Actions tự động build APK hoặc mở bằng Android Studio."
fi
