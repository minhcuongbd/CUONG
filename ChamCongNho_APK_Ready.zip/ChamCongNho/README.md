# Nhắc Chấm Công (Android MVP source)

Prototype Android app source for a worker attendance reminder.

## Included in this prototype
- Two shifts: day 06:00–15:00 and night 15:00–23:00.
- Save the current GPS position as the company location.
- Foreground location service checks location about once per minute.
- Within a 150 m radius of the saved location, it sends a high-priority alarm notification every check until the user manually confirms attendance.
- Local history for the last 14 days, by shift.

## Important limitations
- This project is source code, not a compiled or tested APK.
- GPS polling is approximate and Android may throttle location updates.
- The app cannot run if the user force-stops it, the phone is powered off, or required permissions are denied. Battery optimization settings can also affect reliability.
- Attendance is a manual confirmation in this app; it does not read the employer's actual time-clock system.
- For Android 11+, background location permission may need to be enabled separately in Settings. Notification and alarm behavior varies by Android manufacturer/version.
- Before production use, test on the target phone, improve permission onboarding, battery optimization guidance, reboot handling, stale location checks, and notification action behavior.

## Build in Android Studio
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK.
2. Open this `ChamCongNho` folder as a project.
3. Allow Gradle sync to download dependencies.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location after a successful build.

Package ID: `com.example.chamcongnho`
Version: `0.1.0` (prototype)
