package com.example.chamcongnho

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Build
import android.os.Bundle
import android.widget.*
import android.view.ViewGroup
import android.graphics.Typeface
import android.content.Context
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("attendance", Context.MODE_PRIVATE) }
    private val requestCode = 42
    private val bgLocationRequestCode = 43
    private lateinit var status: TextView
    private lateinit var history: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFFF6F8FC.toInt())
        }

        fun text(value: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
            text = value; textSize = size; setTextColor(0xFF172033.toInt())
            if (bold) setTypeface(null, Typeface.BOLD)
            setPadding(0, 8, 0, 8)
        }

        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { action() }
        }

        root.addView(text("NHẮC CHẤM CÔNG", 25f, true))
        root.addView(text("Ca ngày 06:00–15:00  •  Ca đêm 15:00–23:00", 15f))
        status = text("Đang kiểm tra trạng thái…", 16f, true)
        root.addView(status)

        root.addView(button("1. LƯU VỊ TRÍ CÔNG TY HIỆN TẠI") { saveCompanyLocation() })
        root.addView(text("Đứng tại công ty khi bấm nút này. App sẽ dùng vị trí này làm tâm vùng nhắc nhở (bán kính 150 m).", 13f))
        root.addView(button("2. BẬT THEO DÕI GPS NỀN") { requestAndStartTracking() })
        root.addView(button("DỪNG THEO DÕI") { stopService(Intent(this, TrackingService::class.java)); refresh() })
        root.addView(button("ĐÃ CHẤM CÔNG – XÁC NHẬN CA HIỆN TẠI") { markAttendance() })
        root.addView(text("LỊCH SỬ GẦN ĐÂY", 19f, true))

        history = text("", 14f)
        root.addView(history, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0).apply { height = ViewGroup.LayoutParams.WRAP_CONTENT })
        root.addView(text("Lưu ý: cần cấp quyền vị trí nền và thông báo. Android có thể giới hạn hoạt động nếu buộc dừng app hoặc tắt nguồn.", 12f))

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun saveCompanyLocation() {
        if (!hasLocationPermission()) { requestPermissionsNow(); return }
        LocationServices.getFusedLocationProviderClient(this).lastLocation
            .addOnSuccessListener { loc: Location? ->
                if (loc == null) { toast("Chưa lấy được vị trí. Bật GPS và thử lại ngoài trời."); return@addOnSuccessListener }
                prefs.edit().putString("company_lat", loc.latitude.toString()).putString("company_lon", loc.longitude.toString()).apply()
                toast("Đã lưu vị trí công ty. Tọa độ: %.5f, %.5f".format(loc.latitude, loc.longitude)); refresh()
            }
    }

    private fun requestAndStartTracking() {
        if (!hasLocationPermission()) { requestPermissionsNow(); return }
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), requestCode); return
        }
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_BACKGROUND_LOCATION), bgLocationRequestCode)
        }
        if (prefs.getString("company_lat", null) == null) { toast("Hãy lưu vị trí công ty trước."); return }
        ContextCompat.startForegroundService(this, Intent(this, TrackingService::class.java))
        toast("Đã yêu cầu bật theo dõi GPS nền."); refresh()
    }

    private fun hasLocationPermission() = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestPermissionsNow() {
        // Android 11+ requires foreground location to be requested separately BEFORE background location
        val permissions = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        ActivityCompat.requestPermissions(this, permissions.toTypedArray(), requestCode)
    }

    private fun markAttendance() {
        val shift = currentShift() ?: run { toast("Hiện không nằm trong giờ ca ngày hoặc ca đêm."); return }
        val key = keyFor(shift)
        prefs.edit().putBoolean("done_$key", true).putString("time_$key", SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())).apply()
        refresh(); toast("Đã lưu xác nhận chấm công: $shift")
    }

    private fun currentShift(): String? {
        val h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return if (h in 6..14) "Ca ngày" else if (h in 15..22) "Ca đêm" else null
    }

    private fun keyFor(shift: String): String = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) + "_" + if (shift == "Ca ngày") "day" else "night"

    private fun refresh() {
        val shift = currentShift()
        val loc = if (prefs.getString("company_lat", null) != null) "Đã lưu vị trí công ty" else "Chưa thiết lập vị trí công ty"
        val currentKey = shift?.let { keyFor(it) }
        val done = currentKey?.let { prefs.getBoolean("done_$it", false) } ?: false
        status.text = "$loc\nCa hiện tại: ${shift ?: "Ngoài giờ ca"}\nTrạng thái: ${if (done) "ĐÃ XÁC NHẬN" else "CHƯA XÁC NHẬN"}"

        val lines = mutableListOf<String>()
        for (offset in 0..13) {
            val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -offset) }
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
            for ((name, suffix) in listOf("Ca ngày" to "day", "Ca đêm" to "night")) {
                val key = "${date}_$suffix"
                val checked = prefs.getBoolean("done_$key", false)
                val time = prefs.getString("time_$key", "") ?: ""
                lines.add("${if (checked) "✓" else "○"}  $date  •  $name  •  ${if (checked) "Đã xác nhận $time" else "Chưa xác nhận"}")
            }
        }
        history.text = lines.joinToString("\n")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            toast("Đã cấp quyền vị trí khi dùng app. Nhấn BẬT THEO DÕI GPS NỀN để cấp thêm quyền chạy nền.")
        }
    }
}
