package com.example.chamcongnho

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TrackingService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("attendance", Context.MODE_PRIVATE) }
    private val fused by lazy { LocationServices.getFusedLocationProviderClient(this) }
    private val channelId = "attendance_alerts"
    private val serviceId = 1001
    private val alertId = 1002

    private val checkTask = object : Runnable {
        override fun run() {
            checkLocation()
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val notification = buildNotification("Đang theo dõi vị trí công ty")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(serviceId, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        } else {
            startForeground(serviceId, notification)
        }
        checkLocation()
        handler.postDelayed(checkTask, 60_000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun checkLocation() {
        val lat = prefs.getString("company_lat", null)?.toDoubleOrNull() ?: return
        val lon = prefs.getString("company_lon", null)?.toDoubleOrNull() ?: return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return

        try {
            fused.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
                .addOnSuccessListener { location ->
                    if (location != null) evaluate(location, lat, lon)
                }
        } catch (_: SecurityException) { }
    }

    private fun evaluate(location: Location, lat: Double, lon: Double) {
        val target = Location("company").apply { latitude = lat; longitude = lon }
        val distance = location.distanceTo(target)
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        val shift = when (hour) { in 6..14 -> "day"; in 15..22 -> "night"; else -> null }
        val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val key = shift?.let { "${date}_$it" }

        if (distance <= 150f && key != null && !prefs.getBoolean("done_$key", false)) {
            val shiftName = if (shift == "day") "CA NGÀY" else "CA ĐÊM"
            val now = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            val notification = NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("⚠ ĐỪNG QUÊN CHẤM CÔNG!")
                .setContentText("Bạn đang ở gần công ty ($shiftName). Hãy chấm công rồi mở app xác nhận. $now")
                .setStyle(NotificationCompat.BigTextStyle().bigText("Bạn đang ở trong bán kính 150 m quanh công ty. Hãy chấm công tại máy rồi mở Nhắc Chấm Công và nhấn ĐÃ CHẤM CÔNG."))
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setOnlyAlertOnce(false)
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .build()
            val manager = getSystemService(NotificationManager::class.java)
            manager.cancel(alertId)
            manager.notify(alertId, notification)
        }

        getSystemService(NotificationManager::class.java).notify(serviceId, buildNotification("Đang theo dõi GPS • cách công ty ${distance.toInt()} m"))
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            val alert = NotificationChannel(channelId, "Báo động chấm công", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Nhắc chấm công khi điện thoại vào vùng công ty"
                enableVibration(true)
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM), AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val service = NotificationChannel("tracking_status", "Trạng thái theo dõi", NotificationManager.IMPORTANCE_LOW)
            manager.createNotificationChannel(alert)
            manager.createNotificationChannel(service)
        }
    }

    private fun buildNotification(text: String): Notification = NotificationCompat.Builder(this, "tracking_status")
        .setSmallIcon(android.R.drawable.ic_menu_mylocation)
        .setContentTitle("Nhắc Chấm Công đang chạy")
        .setContentText(text)
        .setOngoing(true)
        .setCategory(NotificationCompat.CATEGORY_SERVICE)
        .build()

    override fun onDestroy() {
        handler.removeCallbacks(checkTask)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
