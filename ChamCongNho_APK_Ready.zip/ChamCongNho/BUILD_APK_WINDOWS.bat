@echo off
chcp 65001 >nul
echo ========================================================
echo   TU DONG BIEN DICH APK - NHAC CHAM CONG (v0.1.0)
echo ========================================================
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Dang chay gradle assembleDebug...
    call gradle assembleDebug
    echo.
    echo File APK da duoc tao tai: app\build\outputs\apk\debug\app-debug.apk
    pause
    exit /b 0
)
echo Vui long mo thu muc nay bang Android Studio hoac tai len GitHub Actions de lay file APK!
pause
